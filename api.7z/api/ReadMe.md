Swagger 文件
> http://localhost:9099/api-docs

Swagger Ui
> http://localhost:9099/swagger-ui/index.html

H2 Database
> http://localhost:9099/h2-console
> 
> JDBC URL: jdbc:h2:file:./database/mydb
>
> User Name: sa
>
> Password: 留空即可
