package com.example.api.service;

import com.example.api.dto.CoveragesDTO;
import com.example.api.dto.PolicyDTO;
import com.example.api.dto.UserDatatDTO;
import com.example.api.util.ExportPdfUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PdfService {

    @Autowired
    private TemplateEngine templateEngine;

    public byte[] generatePolicyPdf() {
        // 模擬資料
        UserDatatDTO userDatatDTO = new UserDatatDTO();
        userDatatDTO.setName("王小明");
        userDatatDTO.setId("A123456789");
        userDatatDTO.setPhone("0912345678");

        PolicyDTO policyDTO = new PolicyDTO();
        policyDTO.setPolicyNo("100000000012");
        policyDTO.setPoIssueDate("100/01/01");

        List<CoveragesDTO> coveragesDTOList = new ArrayList<>();
        CoveragesDTO coveragesDTO1 = new CoveragesDTO();
        coveragesDTO1.setPlanType("意外險");
        coveragesDTO1.setFaceAmt(10000000.00);
        coveragesDTO1.setPremAmt(2000);
        coveragesDTOList.add(coveragesDTO1);
        CoveragesDTO coveragesDTO2 = new CoveragesDTO();
        coveragesDTO2.setPlanType("醫療險");
        coveragesDTO2.setFaceAmt(500000.00);
        coveragesDTO2.setPremAmt(150);
        coveragesDTOList.add(coveragesDTO2);
        CoveragesDTO coveragesDTO3 = new CoveragesDTO();
        coveragesDTO3.setPlanType("壽險");
        coveragesDTO3.setFaceAmt(2000000.00);
        coveragesDTO3.setPremAmt(3000);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);
        coveragesDTOList.add(coveragesDTO3);

        Context context = new Context();
        context.setVariable("applicant", userDatatDTO);
        context.setVariable("policy", policyDTO);
        context.setVariable("coverages", coveragesDTOList);

        return ExportPdfUtil.htmlToPdf(templateEngine, "policy.html", context);
    }

}
