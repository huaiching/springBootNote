package com.example.api.dto;

public class PolicyDTO {
    private String policyNo;
    private String poIssueDate;

    public String getPoIssueDate() {
        return poIssueDate;
    }

    public void setPoIssueDate(String poIssueDate) {
        this.poIssueDate = poIssueDate;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }
}
