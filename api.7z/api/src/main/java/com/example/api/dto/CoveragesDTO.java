package com.example.api.dto;

public class CoveragesDTO {
    private String planType;
    private Double faceAmt;
    private Integer premAmt;

    public String getPlanType() {
        return planType;
    }

    public void setPlanType(String planType) {
        this.planType = planType;
    }

    public Double getFaceAmt() {
        return faceAmt;
    }

    public void setFaceAmt(Double faceAmt) {
        this.faceAmt = faceAmt;
    }

    public Integer getPremAmt() {
        return premAmt;
    }

    public void setPremAmt(Integer premAmt) {
        this.premAmt = premAmt;
    }
}
