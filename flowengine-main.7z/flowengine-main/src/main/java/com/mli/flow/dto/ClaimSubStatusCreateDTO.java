package com.mli.flow.dto;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "理賠 子流程變更 輸入資料 (新增案件)")
public class ClaimSubStatusCreateDTO {
    @Schema(description = "申請人ID")
    private String clientId;
    @Schema(description = "建檔序號")
    private Integer claimSeq;
    @Schema(description = "負責人")
    private String omnerUser;
    @Schema(description = "處理者")
    private String processUser;
    @Schema(description = "子流程分類")
    private String flowCategory;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public Integer getClaimSeq() {
        return claimSeq;
    }

    public void setClaimSeq(Integer claimSeq) {
        this.claimSeq = claimSeq;
    }

    public String getOmnerUser() {
        return omnerUser;
    }

    public void setOmnerUser(String omnerUser) {
        this.omnerUser = omnerUser;
    }

    public String getProcessUser() {
        return processUser;
    }

    public void setProcessUser(String processUser) {
        this.processUser = processUser;
    }

    public String getFlowCategory() {
        return flowCategory;
    }

    public void setFlowCategory(String flowCategory) {
        this.flowCategory = flowCategory;
    }
}
