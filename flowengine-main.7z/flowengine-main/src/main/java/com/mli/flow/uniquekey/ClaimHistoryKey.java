package com.mli.flow.uniquekey;

import io.swagger.v3.oas.annotations.media.Schema;

import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class ClaimHistoryKey implements Serializable {
    private static final long serialVersionUID = 1L;
    @Schema(description = "當前流程 UUID")
    private String case_uuid;

    @Schema(description = "主流程 UUID")
    private String mainUuid;

    @Schema(description = "子流程 UUID")
    private String subUuid;

    public ClaimHistoryKey() {
    }

    public String getCase_uuid() {
        return case_uuid;
    }

    public void setCase_uuid(String case_uuid) {
        this.case_uuid = case_uuid;
    }

    public String getMainUuid() {
        return mainUuid;
    }

    public void setMainUuid(String mainUuid) {
        this.mainUuid = mainUuid;
    }

    public String getSubUuid() {
        return subUuid;
    }

    public void setSubUuid(String subUuid) {
        this.subUuid = subUuid;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        ClaimHistoryKey that = (ClaimHistoryKey) o;
        return Objects.equals(case_uuid, that.case_uuid) && Objects.equals(mainUuid, that.mainUuid) && Objects.equals(subUuid, that.subUuid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(case_uuid, mainUuid, subUuid);
    }
}
