package com.mli.flow.service;

import com.mli.flow.entity.ClaimHistoryEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ClaimHistoryService {
    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * 從 案件歷史資訊 取得 特定子流程資訊
     * @param subUuid 子流程 UUID
     * @return
     */
    public List<ClaimHistoryEntity> getSubClaimHistory(String subUuid) {
        String sql = "SELECT * FROM claim_history " +
                "WHERE sub_uuid = :subUuid " +
                "ORDER BY process_date DESC, process_time DESC ";
        Map<String, Object> params = new HashMap<>();
        params.put("subUuid", subUuid);
        return namedParameterJdbcTemplate.query(sql, params, new BeanPropertyRowMapper<>(ClaimHistoryEntity.class));
    }
}
