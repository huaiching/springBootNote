package com.mli.flow.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.mli.flow.entity.ClaimMainStatusEntity;

import java.util.List;

public interface ClaimStatusRepository extends JpaRepository<ClaimMainStatusEntity, String> {
    List<ClaimMainStatusEntity> findByClientIdAndClaimSeq(String clientId, Integer cliamSeq);
}
