package com.mli.flow.dto;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "子流程 UUID")
public class SubUuidDTO {
    @Schema(description = "子流程 UUID")
    private String subUuid;

    public String getSubUuid() {
        return subUuid;
    }

    public void setSubUuid(String subUuid) {
        this.subUuid = subUuid;
    }
}
