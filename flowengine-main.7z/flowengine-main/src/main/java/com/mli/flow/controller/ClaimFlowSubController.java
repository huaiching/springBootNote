package com.mli.flow.controller;

import com.mli.flow.dto.ClaimSubStatusCreateDTO;
import com.mli.flow.dto.ClaimSubStatusModifyDTO;
import com.mli.flow.dto.ClientIdAndClaimSeqDTO;
import com.mli.flow.dto.SubUuidDTO;
import com.mli.flow.entity.ClaimSubStatusEntity;
import com.mli.flow.service.ClaimFlowSubService;
import com.mli.flow.vo.ClaimSubStatusVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;


@RestController
@RequestMapping("/claimFlowSub")
@Tag(name = "Claim Flow Sub Controller", description = "理賠流程引擎 子流程 API")
public class ClaimFlowSubController {
    @Autowired
    private ClaimFlowSubService claimFlowSubService;

    @PostMapping("/createClaimSubStatus/v1")
    @Operation(summary = "子流程 新增案件", description = "子流程 新增案件")
    public ResponseEntity<ClaimSubStatusVO> createClaimSubStatus(@RequestBody ClaimSubStatusCreateDTO claimSubStatusCreateDTO) {
        return ResponseEntity.ok(claimFlowSubService.createClaimSubStatus(claimSubStatusCreateDTO));
    }

    @PostMapping("/nextClaimSubStatus/v1")
    @Operation(summary = "子流程 前往下一關", description = "子流程 前往下一關")
    public ResponseEntity<ClaimSubStatusVO> nextClaimSubStatus(@RequestBody ClaimSubStatusModifyDTO claimSubStatusModifyDTO) {
        return ResponseEntity.ok(claimFlowSubService.nextClaimSubStatus(claimSubStatusModifyDTO));
    }

    @PostMapping("/getClaimSubStatus/v1")
    @Operation(summary = "取得 子流程 目前案件資訊", description = "取得 子流程 目前案件資訊")
    public ResponseEntity<List<ClaimSubStatusEntity>> getClaimSubStatus(@RequestBody ClientIdAndClaimSeqDTO clientIdAndClaimSeqDto) {
        return ResponseEntity.ok(claimFlowSubService.getClaimSubStatus(clientIdAndClaimSeqDto.getClientId(), clientIdAndClaimSeqDto.getClaimSeq()));
    }

    @PostMapping("/exportNote/v1")
    @Operation(summary = "產生 案件子流程 簽核意見表", description = "產生 案件子流程 簽核意見表")
    public ResponseEntity<Resource> exportNote(@RequestBody SubUuidDTO subUuidDTO) {

        byte[] pdfBytes = claimFlowSubService.exportNote(subUuidDTO.getSubUuid());
        String fileName = "exportNote.pdf";
//        String fileName = "exportNote.pdf";

        // 將 byte[] 包裝成 Resource
        Resource resource = new ByteArrayResource(pdfBytes);

        HttpHeaders headers = new HttpHeaders();
        // 關鍵：觸發下載並正確編碼檔名
        headers.setContentDispositionFormData("attachment",
                URLEncoder.encode(fileName, StandardCharsets.UTF_8));

        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_OCTET_STREAM)   // 通用下載類型
                // .contentType(MediaType.APPLICATION_PDF)        // 也可以明確指定 PDF
                .contentLength(pdfBytes.length)
                .body(resource);
    }
}
