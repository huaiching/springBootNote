package com.mli.flow.controller;

import com.mli.flow.dto.ClientIdAndClaimSeqDTO;
import com.mli.flow.service.ClaimFlowMainService;
import com.mli.flow.vo.ClaimHistoryVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/claimFlowHistory")
@Tag(name = "Claim Flow History Controller", description = "理賠流程引擎 案件歷史 API")
public class ClaimFlowHistoryController {
    @Autowired
    private ClaimFlowMainService claimFlowMainService;

    @PostMapping("/getClaimHistory/v1")
    @Operation(summary = "取得 案件歷史資訊", description = "取得 案件歷史資訊")
    public ResponseEntity<List<ClaimHistoryVO>> getClaimHistory(@RequestBody ClientIdAndClaimSeqDTO clientIdAndClaimSeqDto) {
        return ResponseEntity.ok(claimFlowMainService.getClaimHistory(clientIdAndClaimSeqDto.getClientId(), clientIdAndClaimSeqDto.getClaimSeq()));
    }
}
