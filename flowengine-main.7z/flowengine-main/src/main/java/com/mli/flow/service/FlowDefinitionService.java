package com.mli.flow.service;

import com.mli.flow.entity.FlowDefinitionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FlowDefinitionService {
    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * 取得 流程定義表
     * @param systemType 系統類型
     * @return
     */
    public List<FlowDefinitionEntity> getFlowBySystemType(String systemType) {
        String sql = "SELECT * FROM flow_definition " +
                "WHERE system_type = :systemType ";
        Map<String, Object> params = new HashMap<>();
        params.put("systemType", systemType);

        return namedParameterJdbcTemplate.query(sql, params, new BeanPropertyRowMapper<>(FlowDefinitionEntity.class));
    }

    /**
     * 取得 流程定義表
     * @param systemType 系統類型
     * @param flowType 流程類型
     * @param flowCategory 流程分類
     * @param currentStatus 目前節點代碼
     * @return
     */
    public FlowDefinitionEntity getFlowBySystem(String systemType, String flowType, String flowCategory, String currentStatus) {
        String sql = "SELECT * FROM flow_definition " +
                "WHERE system_type = :systemType" +
                "  AND flow_type = :flowType" +
                "  AND flow_category = :flowCategory" +
                "  AND current_status = :currentStatus ";
        Map<String, Object> params = new HashMap<>();
        params.put("systemType", systemType);
        params.put("flowType", flowType);
        params.put("flowCategory", flowCategory);
        params.put("currentStatus", currentStatus);

        List<FlowDefinitionEntity> flowDefinitionEntityList = namedParameterJdbcTemplate.query(sql, params, new BeanPropertyRowMapper<>(FlowDefinitionEntity.class));

        if (CollectionUtils.isEmpty(flowDefinitionEntityList)) {
            return new FlowDefinitionEntity();
        } else {
            return flowDefinitionEntityList.get(0);
        }
    }

    /**
     * 取得 節點中文
     * @param systemType 系統類型
     * @param flowType 流程類型
     * @param flowCategory 流程分類
     * @param currentStatus 目前節點代碼
     * @return
     */
    public String getStatusDesc(String systemType, String flowType, String flowCategory, String currentStatus) {
        String sql = "SELECT * FROM flow_definition " +
                "WHERE system_type = :systemType" +
                "  AND flow_type = :flowType" +
                "  AND flow_category = :flowCategory" +
                "  AND current_status = :currentStatus ";
        Map<String, Object> params = new HashMap<>();
        params.put("systemType", systemType);
        params.put("flowType", flowType);
        params.put("flowCategory", flowCategory);
        params.put("currentStatus", currentStatus);

        List<FlowDefinitionEntity> flowDefinitionEntityList = namedParameterJdbcTemplate.query(sql, params, new BeanPropertyRowMapper<>(FlowDefinitionEntity.class));

        if (CollectionUtils.isEmpty(flowDefinitionEntityList)) {
            return "";
        } else {
            return flowDefinitionEntityList.get(0).getCurrentDesc();
        }
    }

}
