package com.mli.flow.service;

import com.mli.flow.constants.ClaimStatusEnum;
import com.mli.flow.dto.ClaimSubStatusCreateDTO;
import com.mli.flow.dto.ClaimSubStatusModifyDTO;
import com.mli.flow.dto.Export.ClaimSubNoteDataDTO;
import com.mli.flow.entity.ClaimHistoryEntity;
import com.mli.flow.entity.ClaimSubStatusEntity;
import com.mli.flow.entity.FlowDefinitionEntity;
import com.mli.flow.exceptions.BusinessException;
import com.mli.flow.repository.ClaimHistoryRepository;
import com.mli.flow.repository.ClaimSubStatusRepository;
import com.mli.flow.util.DateUtil;
import com.mli.flow.util.ExcelToPdfUtil;
import com.mli.flow.util.ExcelUtil;
import com.mli.flow.vo.ClaimStatusVO;
import com.mli.flow.vo.ClaimSubStatusVO;
import org.jxls.common.Context;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.*;

/**
 * 理賠 流程引擎 - 子流程
 */
@Service
public class ClaimFlowSubService {
    @Autowired
    private ClaimSubStatusRepository claimSubStatusRepository;
    @Autowired
    private ClaimHistoryRepository claimHistoryRepository;
    @Autowired
    private ClaimSpELService claimSpELService;
    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @Autowired
    private FlowDefinitionService flowDefinitionService;
    @Autowired
    private ClaimFlowMainService claimFlowMainService;
    @Autowired
    private ClaimHistoryService claimHistoryService;

    private final String SYSTEM_TYPE = "CLAIM";

    /**
     * 理賠流程 - 子流程 - 新增案件
     * @param claimSubStatusCreateDTO 理賠 主流程變更 輸入資料
     * @return ClaimSubStatusVo 新增案件資訊
     */
    @Transactional
    public ClaimSubStatusVO createClaimSubStatus(ClaimSubStatusCreateDTO claimSubStatusCreateDTO) {
        String clientId = claimSubStatusCreateDTO.getClientId();
        Integer claimSeq = claimSubStatusCreateDTO.getClaimSeq();
        String omnerUser = claimSubStatusCreateDTO.getOmnerUser();
        String processUser = claimSubStatusCreateDTO.getProcessUser();
        String flowCategory = claimSubStatusCreateDTO.getFlowCategory();

        if (StringUtils.isEmpty(clientId)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：clientId 空白");
        }
        if (StringUtils.isEmpty(claimSeq)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：claimSeq 空白");
        }

        // 取得 主流程 案件資訊
        ClaimStatusVO claimStatusVo = claimFlowMainService.getClaimStatus(clientId, claimSeq);
        if (claimStatusVo == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "案件主流程 不存在，clientId=" + clientId + " claimSeq=" + claimSeq);
        }

        // 取得 下一關節點
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("status", "");
        dataMap.put("subFlow", true);
        dataMap.put("type", "S");
        dataMap.put("category", flowCategory);

        FlowDefinitionEntity flowDefinition = claimSpELService.getFlow(SYSTEM_TYPE, dataMap);
        if (flowDefinition == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "查無子流程定義，clientId=" + clientId + " claimSeq=" + claimSeq);
        }
        String nextStatus = flowDefinition.getNextStatus();

        // 建立資料
        ClaimSubStatusEntity newClaimSubStatus = new ClaimSubStatusEntity();
        newClaimSubStatus.setStatusUuid(UUID.randomUUID().toString());
        newClaimSubStatus.setSubUuid(UUID.randomUUID().toString());
        newClaimSubStatus.setMainUuid(claimStatusVo.getMainUuid());
        newClaimSubStatus.setClientId(clientId);
        newClaimSubStatus.setClaimSeq(claimSeq);
        newClaimSubStatus.setFlowCategory(flowCategory);
        newClaimSubStatus.setStatus(nextStatus);
        newClaimSubStatus.setOwnerUser(omnerUser);
        newClaimSubStatus.setNote("");
        newClaimSubStatus.setProcessUser(processUser);
        newClaimSubStatus.setProcessDate(DateUtil.getToday());
        newClaimSubStatus.setProcessTime(DateUtil.getTime());

        // 新增案件狀態
        claimSubStatusRepository.save(newClaimSubStatus);

        // 新增案件歷程
        ClaimHistoryEntity newClaimHistory = new ClaimHistoryEntity();
        BeanUtils.copyProperties(newClaimSubStatus, newClaimHistory);
        newClaimHistory.setFlowType("S");
        newClaimHistory.setMainStatus(claimStatusVo.getStatus());
        newClaimHistory.setSubStatus(nextStatus);
        newClaimHistory.setMainFlowCategory(claimStatusVo.getFlowCategory());
        newClaimHistory.setSubFlowCategory(newClaimSubStatus.getFlowCategory());
        claimHistoryRepository.save(newClaimHistory);

        // 設定 回傳資料
        ClaimSubStatusVO output = new ClaimSubStatusVO();
        BeanUtils.copyProperties(newClaimSubStatus, output);
        output.setStatusDesc(flowDefinitionService.getStatusDesc(SYSTEM_TYPE, "S", newClaimSubStatus.getFlowCategory(), newClaimSubStatus.getStatus()));

        return output;
    }

    /**
     * 理賠流程 - 子流程 - 前往下一關
     * @param claimSubStatusModifyDTO 理賠 主流程變更 輸入資料
     * @return ClaimStatusEntity 下一關案件資訊
     */
    @Transactional
    public ClaimSubStatusVO nextClaimSubStatus(ClaimSubStatusModifyDTO claimSubStatusModifyDTO) {
        String subUuid = claimSubStatusModifyDTO.getSubUuid();
        String omnerUser = claimSubStatusModifyDTO.getOmnerUser();
        String processUser = claimSubStatusModifyDTO.getProcessUser();
        String note = claimSubStatusModifyDTO.getNote();

        if (StringUtils.isEmpty(subUuid)) {
            throw new RuntimeException("輸入參數錯誤：subUuid 空白");
        }

        // 取得目前案件資訊
        ClaimSubStatusVO claimSubStatusVo = getClaimSubStatus(subUuid);
        if (claimSubStatusVo == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "前往下一關 執行錯誤，案件不存在，subUuid=" + subUuid);
        }

        // 取得 主流程 案件資訊
        ClaimStatusVO claimStatusVo = claimFlowMainService.getClaimStatus(claimSubStatusVo.getClientId(), claimSubStatusVo.getClaimSeq());
        if (claimStatusVo == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "案件主流程 不存在，clientId=" + claimSubStatusVo.getClientId() + " claimSeq=" + claimSubStatusVo.getClaimSeq());
        }

        // 取得 下一關節點
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("status", claimSubStatusVo.getStatus());
        dataMap.put("subFlow", true);
        dataMap.put("type", "S");
        dataMap.put("category", claimSubStatusVo.getFlowCategory());

        FlowDefinitionEntity flowDefinition = claimSpELService.getFlow(SYSTEM_TYPE, dataMap);
        if (flowDefinition == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "前往下一關 執行錯誤，找不到案件狀態，subUuid=" + subUuid);
        }
        String nextStatus = flowDefinition.getNextStatus();

        // 取得 下一個流程的流程定義
        FlowDefinitionEntity nextFlowDefinitionEntity = flowDefinitionService.getFlowBySystem(SYSTEM_TYPE, "S", claimSubStatusVo.getFlowCategory(), nextStatus);

        // 建立資料: 刪除
        ClaimSubStatusEntity oriClaimSubStatus = new ClaimSubStatusEntity();
        BeanUtils.copyProperties(claimSubStatusVo, oriClaimSubStatus);

        // 建立資料: 新增
        ClaimSubStatusEntity newClaimSubStatus = new ClaimSubStatusEntity();
        newClaimSubStatus.setStatusUuid(UUID.randomUUID().toString());
        newClaimSubStatus.setSubUuid(claimSubStatusVo.getSubUuid());
        newClaimSubStatus.setMainUuid(claimSubStatusVo.getMainUuid());
        newClaimSubStatus.setClientId(claimSubStatusVo.getClientId());
        newClaimSubStatus.setClaimSeq(claimSubStatusVo.getClaimSeq());
        newClaimSubStatus.setFlowCategory(claimSubStatusVo.getFlowCategory());
        newClaimSubStatus.setStatus(nextStatus);
        newClaimSubStatus.setOwnerUser(omnerUser);
        newClaimSubStatus.setNote(note);
        newClaimSubStatus.setProcessUser(processUser);
        newClaimSubStatus.setProcessDate(DateUtil.getToday());
        newClaimSubStatus.setProcessTime(DateUtil.getTime());

        // 修改案件狀態: 先刪除，再新增
        claimSubStatusRepository.delete(oriClaimSubStatus);
        // 子流程 最後一關 案件狀態 不寫檔
        if (!StringUtils.isEmpty(nextFlowDefinitionEntity.getNextStatus())) {
            claimSubStatusRepository.save(newClaimSubStatus);
        }

        // 新增案件歷程
        ClaimHistoryEntity newClaimHistory = new ClaimHistoryEntity();
        BeanUtils.copyProperties(newClaimSubStatus, newClaimHistory);
        newClaimHistory.setFlowType("S");
        newClaimHistory.setMainStatus(claimStatusVo.getStatus());
        newClaimHistory.setSubStatus(nextStatus);
        newClaimHistory.setMainFlowCategory(claimStatusVo.getFlowCategory());
        newClaimHistory.setSubFlowCategory(newClaimSubStatus.getFlowCategory());
        claimHistoryRepository.save(newClaimHistory);

        // 設定 回傳資料
        ClaimSubStatusVO output = new ClaimSubStatusVO();
        BeanUtils.copyProperties(newClaimSubStatus, output);
        output.setStatusDesc(flowDefinitionService.getStatusDesc(SYSTEM_TYPE, "S", newClaimSubStatus.getFlowCategory(), newClaimSubStatus.getStatus()));

        return output;
    }

    /**
     * 取得 子流程 目前案件資訊 (By 申請人ID + 建檔序號)
     * @param clientId 申請人ID
     * @param claimSeq 建檔序號
     * @return List<ClaimSubStatusVo> 目前案件資訊
     */
    public List<ClaimSubStatusEntity> getClaimSubStatus(String clientId, Integer claimSeq) {
        if (StringUtils.isEmpty(clientId)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：clientId 空白");
        }
        if (StringUtils.isEmpty(claimSeq)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：claimSeq 空白");
        }

        // 取得 目前案件資訊
        List<ClaimSubStatusEntity> claimSubStatusEntityList =  claimSubStatusRepository.findByClientIdAndClaimSeq(clientId, claimSeq);
        return claimSubStatusEntityList;
    }

    /**
     * 取得 子流程 目前案件資訊 (By 子流程 UUID)
     * @param subUuid 子流程 UUID
     * @return ClaimSubStatusVo 目前案件資訊
     */
    public ClaimSubStatusVO getClaimSubStatus(String subUuid) {
        if (StringUtils.isEmpty(subUuid)) {
            throw new RuntimeException("輸入參數錯誤：subUuid 空白");
        }

        // 取得 目前案件資訊
        List<ClaimSubStatusEntity> claimSubStatusEntityList =  claimSubStatusRepository.findBySubUuid(subUuid);
        if (CollectionUtils.isEmpty(claimSubStatusEntityList)) {
            return null;
        } else {
            // 設定回傳
            ClaimSubStatusVO claimSubStatusVo = new ClaimSubStatusVO();
            BeanUtils.copyProperties(claimSubStatusEntityList.get(0), claimSubStatusVo);
            claimSubStatusVo.setStatusDesc(ClaimStatusEnum.getDescByStatusCode(claimSubStatusVo.getStatus()));

            return claimSubStatusVo;
        }
    }

    /**
     * 產生 案件子流程 簽核意見表
     * @param subUuid 子流程 UUID
     * @return byte[] PDF
     */
    public byte[] exportNote(String subUuid) {
        // 取得資料
        List<ClaimHistoryEntity> claimHistoryEntityList = claimHistoryService.getSubClaimHistory(subUuid);
        if (CollectionUtils.isEmpty(claimHistoryEntityList)) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "案件不存在");
        }
        // 資料設定
        String clientId = claimHistoryEntityList.get(0).getClientId();
        Integer claimSeq = claimHistoryEntityList.get(0).getClaimSeq();
        String mainStatusDesc = flowDefinitionService.getStatusDesc(SYSTEM_TYPE, "M", claimHistoryEntityList.get(0).getMainFlowCategory(), claimHistoryEntityList.get(0).getMainStatus());

        List<ClaimSubNoteDataDTO> claimSubNoteDataDTOList = new ArrayList<>();
        for (ClaimHistoryEntity claimHistoryEntity : claimHistoryEntityList) {
            String subStatusDesc = flowDefinitionService.getStatusDesc(SYSTEM_TYPE, "S", claimHistoryEntity.getSubFlowCategory(), claimHistoryEntity.getSubStatus());

            ClaimSubNoteDataDTO claimSubNoteDataDTO = new ClaimSubNoteDataDTO();
            claimSubNoteDataDTO.setSubStatus(subStatusDesc);
            claimSubNoteDataDTO.setOwnerUser(claimHistoryEntity.getOwnerUser());
            claimSubNoteDataDTO.setProcessDate(claimHistoryEntity.getProcessDate());
            claimSubNoteDataDTO.setProcessTime(claimHistoryEntity.getProcessTime());
            claimSubNoteDataDTO.setNote(claimHistoryEntity.getNote());

            claimSubNoteDataDTOList.add(claimSubNoteDataDTO);
        }

        // 設定 報表資料內容
        Context context = new Context();
        context.putVar("clientId", clientId);
        context.putVar("claimSeq", claimSeq);
        context.putVar("mainStatus", mainStatusDesc);
        context.putVar("subUuid", subUuid);
        context.putVar("data", claimSubNoteDataDTOList);

        byte[] excel = ExcelUtil.generateExcel("ClaimSubNote.xlsx", context);

        try {
            return ExcelToPdfUtil.excelToPdf(excel, true);
        } catch (Exception e) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "報表生成失敗：" + e.getMessage());
        }

    }
}
