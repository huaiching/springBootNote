package com.mli.flow.service;

import com.mli.flow.constants.ClaimStatusEnum;
import com.mli.flow.dto.ClaimMainStatusDTO;
import com.mli.flow.entity.ClaimHistoryEntity;
import com.mli.flow.entity.ClaimMainStatusEntity;
import com.mli.flow.entity.ClaimSubStatusEntity;
import com.mli.flow.entity.FlowDefinitionEntity;
import com.mli.flow.exceptions.BusinessException;
import com.mli.flow.repository.ClaimHistoryRepository;
import com.mli.flow.repository.ClaimStatusRepository;
import com.mli.flow.repository.ClaimSubStatusRepository;
import com.mli.flow.util.DateUtil;
import com.mli.flow.vo.ClaimHistoryVO;
import com.mli.flow.vo.ClaimStatusVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;

/**
 * 理賠 流程引擎 - 主流程
 */
@Service
public class ClaimFlowMainService {
    @Autowired
    private ClaimStatusRepository claimStatusRepository;
    @Autowired
    private ClaimSubStatusRepository claimSubStatusRepository;
    @Autowired
    private ClaimHistoryRepository claimHistoryRepository;
    @Autowired
    private ClaimSpELService claimSpELService;
    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @Autowired
    private FlowDefinitionService flowDefinitionService;

    private final String SYSTEM_TYPE = "CLAIM";

    /**
     * 理賠流程 - 主流程 - 新增案件
     * @param claimMainStatusDTO 理賠 主流程變更 輸入資料
     * @return ClaimStatusEntity 新增案件資訊
     */
    @Transactional
    public ClaimStatusVO createClaimMainStatus(ClaimMainStatusDTO claimMainStatusDTO) {
        String clientId = claimMainStatusDTO.getClientId();
        Integer claimSeq = claimMainStatusDTO.getClaimSeq();
        String omnerUser = claimMainStatusDTO.getOmnerUser();
        String processUser = claimMainStatusDTO.getProcessUser();

        if (StringUtils.isEmpty(clientId)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：clientId 空白");
        }
        if (StringUtils.isEmpty(claimSeq)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：claimSeq 空白");
        }

        // 取得目前案件資訊
        ClaimStatusVO claimStatusVo = getClaimStatus(clientId, claimSeq);
        if (claimStatusVo != null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "新增案件執行錯誤，案件已存在，clientId=" + clientId + " claimSeq=" + claimSeq);
        }

        // 取得 下一關節點
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("status", "");
        dataMap.put("type", "M");
        dataMap.put("category", "1");
        dataMap.put("subFlow", false);

        FlowDefinitionEntity flowDefinition = claimSpELService.getFlow(SYSTEM_TYPE, dataMap);
        if (flowDefinition == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "新增案件錯誤，找不到案件狀態，clientId=" + clientId + " claimSeq=" + claimSeq);
        }
        String nextStatus = flowDefinition.getNextStatus();

        // 建立資料
        ClaimMainStatusEntity newClaimStatus = new ClaimMainStatusEntity();
        newClaimStatus.setMainUuid(UUID.randomUUID().toString());
        newClaimStatus.setClientId(clientId);
        newClaimStatus.setClaimSeq(claimSeq);
        newClaimStatus.setFlowCategory("1");
        newClaimStatus.setStatus(nextStatus);
        newClaimStatus.setOwnerUser(omnerUser);
        newClaimStatus.setNote("");
        newClaimStatus.setProcessUser(processUser);
        newClaimStatus.setProcessDate(DateUtil.getToday());
        newClaimStatus.setProcessTime(DateUtil.getTime());

        // 新增案件狀態
        claimStatusRepository.save(newClaimStatus);

        // 新增案件歷程
        ClaimHistoryEntity newClaimHistory = new ClaimHistoryEntity();
        BeanUtils.copyProperties(newClaimStatus, newClaimHistory);
        newClaimHistory.setFlowType("M");
        newClaimHistory.setSubUuid("");
        newClaimHistory.setStatusUuid("");
        newClaimHistory.setMainStatus(newClaimStatus.getStatus());
        newClaimHistory.setSubStatus("");
        newClaimHistory.setMainFlowCategory(newClaimStatus.getFlowCategory());
        newClaimHistory.setSubFlowCategory("");
        claimHistoryRepository.save(newClaimHistory);

        // 設定 回傳資料
        ClaimStatusVO output = new ClaimStatusVO();
        BeanUtils.copyProperties(newClaimStatus, output);
        output.setStatusDesc(flowDefinitionService.getStatusDesc(SYSTEM_TYPE, "M", newClaimStatus.getFlowCategory(), newClaimStatus.getStatus()));

        return output;
    }

    /**
     * 理賠流程 - 主流程 - 前往下一關
     * @param claimMainStatusDTO 理賠 主流程變更 輸入資料
     * @return ClaimStatusEntity 下一關案件資訊
     */
    @Transactional
    public ClaimStatusVO nextClaimMainStatus(ClaimMainStatusDTO claimMainStatusDTO) {
        String clientId = claimMainStatusDTO.getClientId();
        Integer claimSeq = claimMainStatusDTO.getClaimSeq();
        String omnerUser = claimMainStatusDTO.getOmnerUser();
        String processUser = claimMainStatusDTO.getProcessUser();

        if (StringUtils.isEmpty(clientId)) {
            throw new RuntimeException("輸入參數錯誤：clientId 空白");
        }
        if (StringUtils.isEmpty(claimSeq)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：claimSeq 空白");
        }

        // 取得目前案件資訊
        ClaimStatusVO claimStatusVo = getClaimStatus(clientId, claimSeq);

        if (claimStatusVo == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "前往下一關 執行錯誤，案件不存在，clientId=" + clientId + " claimSeq=" + claimSeq);
        }

        // 檢查是否有 子流程進行中
        List<ClaimSubStatusEntity> claimSubStatusEntityList = claimSubStatusRepository.findByMainUuid(claimStatusVo.getMainUuid());
        if (!CollectionUtils.isEmpty(claimSubStatusEntityList)) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "尚有子流程進行中，clientId=" + clientId + " claimSeq=" + claimSeq);
        }

        // 取得 下一關節點
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("status", claimStatusVo.getStatus());
        dataMap.put("subFlow", false);
        dataMap.put("type", "M");
        dataMap.put("category", claimStatusVo.getFlowCategory());

        FlowDefinitionEntity flowDefinition = claimSpELService.getFlow(SYSTEM_TYPE, dataMap);
        if (flowDefinition == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "前往下一關 執行錯誤，找不到案件狀態，clientId=" + clientId + " claimSeq=" + claimSeq);
        }
        String nextStatus = flowDefinition.getNextStatus();

        if (StringUtils.isEmpty(nextStatus)) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "無下一關節點，clientId=" + clientId + " claimSeq=" + claimSeq);
        }

        // 建立資料: 刪除
        ClaimMainStatusEntity oriClaimStatus = new ClaimMainStatusEntity();
        BeanUtils.copyProperties(claimStatusVo, oriClaimStatus);

        // 建立資料: 新增
        ClaimMainStatusEntity newClaimStatus = new ClaimMainStatusEntity();
        newClaimStatus.setMainUuid(UUID.randomUUID().toString());
        newClaimStatus.setClientId(clientId);
        newClaimStatus.setClaimSeq(claimSeq);
        newClaimStatus.setFlowCategory(claimStatusVo.getFlowCategory());
        newClaimStatus.setStatus(nextStatus);
        newClaimStatus.setOwnerUser(omnerUser);
        newClaimStatus.setNote("");
        newClaimStatus.setProcessUser(processUser);
        newClaimStatus.setProcessDate(DateUtil.getToday());
        newClaimStatus.setProcessTime(DateUtil.getTime());

        // 修改案件狀態: 先刪除，再新增
        claimStatusRepository.delete(oriClaimStatus);
        claimStatusRepository.save(newClaimStatus);

        // 新增案件歷程
        ClaimHistoryEntity newClaimHistory = new ClaimHistoryEntity();
        BeanUtils.copyProperties(newClaimStatus, newClaimHistory);
        newClaimHistory.setFlowType("M");
        newClaimHistory.setSubUuid("");
        newClaimHistory.setStatusUuid("");
        newClaimHistory.setMainStatus(newClaimStatus.getStatus());
        newClaimHistory.setSubStatus("");
        newClaimHistory.setMainFlowCategory(newClaimStatus.getFlowCategory());
        newClaimHistory.setSubFlowCategory("");
        claimHistoryRepository.save(newClaimHistory);

        // 設定 回傳資料
        ClaimStatusVO output = new ClaimStatusVO();
        BeanUtils.copyProperties(newClaimStatus, output);
        output.setStatusDesc(flowDefinitionService.getStatusDesc(SYSTEM_TYPE, "M", newClaimStatus.getFlowCategory(), newClaimStatus.getStatus()));

        return output;
    }

    /**
     * 理賠流程 - 主流程 - 返回上一關
     * @param claimMainStatusDTO 理賠 主流程變更 輸入資料
     * @return ClaimStatusVo 上一關案件資訊
     */
    @Transactional
    public ClaimStatusVO prewClaimMainStatus(ClaimMainStatusDTO claimMainStatusDTO) {
        String clientId = claimMainStatusDTO.getClientId();
        Integer claimSeq = claimMainStatusDTO.getClaimSeq();
        String omnerUser = claimMainStatusDTO.getOmnerUser();
        String processUser = claimMainStatusDTO.getProcessUser();

        if (StringUtils.isEmpty(clientId)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：clientId 空白");
        }
        if (StringUtils.isEmpty(claimSeq)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：claimSeq 空白");
        }

        // 取得目前案件資訊
        ClaimStatusVO claimStatusVo = getClaimStatus(clientId, claimSeq);

        if (claimStatusVo == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "返回上一關 執行錯誤，案件不存在，clientId=" + clientId + " claimSeq=" + claimSeq);
        }

        // 檢查是否有 子流程進行中
        List<ClaimSubStatusEntity> claimSubStatusEntityList = claimSubStatusRepository.findByMainUuid(claimStatusVo.getMainUuid());
        if (!CollectionUtils.isEmpty(claimSubStatusEntityList)) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "尚有子流程進行中，clientId=" + clientId + " claimSeq=" + claimSeq);
        }

        // 取得 上一關節點
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("status", claimStatusVo.getStatus());
        dataMap.put("subFlow", false);
        dataMap.put("type", "M");
        dataMap.put("category", claimStatusVo.getFlowCategory());

        FlowDefinitionEntity flowDefinition = claimSpELService.getFlow(SYSTEM_TYPE, dataMap);
        if (flowDefinition == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "前往下一關 執行錯誤，找不到案件狀態，clientId=" + clientId + " claimSeq=" + claimSeq);
        }
        String prewStatus = flowDefinition.getPrewStatus();

        if (StringUtils.isEmpty(prewStatus)) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "無上一關節點，clientId=" + clientId + " claimSeq=" + claimSeq);
        }

        // 建立資料: 刪除
        ClaimMainStatusEntity oriClaimStatus = new ClaimMainStatusEntity();
        BeanUtils.copyProperties(claimStatusVo, oriClaimStatus);

        // 建立資料: 新增
        ClaimMainStatusEntity newClaimStatus = new ClaimMainStatusEntity();
        newClaimStatus.setMainUuid(UUID.randomUUID().toString());
        newClaimStatus.setClientId(clientId);
        newClaimStatus.setClaimSeq(claimSeq);
        newClaimStatus.setFlowCategory(claimStatusVo.getFlowCategory());
        newClaimStatus.setStatus(prewStatus);
        newClaimStatus.setOwnerUser(omnerUser);
        newClaimStatus.setNote("");
        newClaimStatus.setProcessUser(processUser);
        newClaimStatus.setProcessDate(DateUtil.getToday());
        newClaimStatus.setProcessTime(DateUtil.getTime());

        // 修改案件狀態: 先刪除，再新增
        claimStatusRepository.delete(oriClaimStatus);
        claimStatusRepository.save(newClaimStatus);

        // 新增案件歷程
        ClaimHistoryEntity newClaimHistory = new ClaimHistoryEntity();
        BeanUtils.copyProperties(newClaimStatus, newClaimHistory);
        newClaimHistory.setFlowType("M");
        newClaimHistory.setSubUuid("");
        newClaimHistory.setStatusUuid("");
        newClaimHistory.setMainStatus(newClaimStatus.getStatus());
        newClaimHistory.setSubStatus("");
        newClaimHistory.setMainFlowCategory(newClaimStatus.getFlowCategory());
        newClaimHistory.setSubFlowCategory("");
        claimHistoryRepository.save(newClaimHistory);

        // 設定 回傳資料
        ClaimStatusVO output = new ClaimStatusVO();
        BeanUtils.copyProperties(newClaimStatus, output);
        output.setStatusDesc(flowDefinitionService.getStatusDesc(SYSTEM_TYPE, "M", newClaimStatus.getFlowCategory(), newClaimStatus.getStatus()));

        return output;
    }

    @Transactional
    public ClaimStatusVO updateOwnerUser(ClaimMainStatusDTO claimMainStatusDTO) {
        String clientId = claimMainStatusDTO.getClientId();
        Integer claimSeq = claimMainStatusDTO.getClaimSeq();
        String omnerUser = claimMainStatusDTO.getOmnerUser();
        String processUser = claimMainStatusDTO.getProcessUser();

        if (StringUtils.isEmpty(clientId)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：clientId 空白");
        }
        if (StringUtils.isEmpty(claimSeq)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：claimSeq 空白");
        }
        if (StringUtils.isEmpty(omnerUser)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：omnerUser 空白");
        }
        if (StringUtils.isEmpty(processUser)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：processUser 空白");
        }

        // 取得目前案件資訊
        ClaimStatusVO claimStatusVo = getClaimStatus(clientId, claimSeq);

        if (claimStatusVo == null) {
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "案件不存在，clientId=" + clientId + " claimSeq=" + claimSeq);
        }

        // 更新 負責人
        ClaimMainStatusEntity claimMainStatusEntity = new ClaimMainStatusEntity();
        BeanUtils.copyProperties(claimStatusVo, claimMainStatusEntity);
        claimMainStatusEntity.setOwnerUser(omnerUser);
        claimMainStatusEntity.setProcessUser(processUser);
        claimMainStatusEntity.setProcessDate(DateUtil.getToday());
        claimMainStatusEntity.setProcessTime(DateUtil.getTime());
        claimStatusRepository.save(claimMainStatusEntity);

        // 設定 回傳資料
        ClaimStatusVO output = new ClaimStatusVO();
        BeanUtils.copyProperties(claimMainStatusEntity, output);
        output.setStatusDesc(flowDefinitionService.getStatusDesc(SYSTEM_TYPE, "M", claimMainStatusEntity.getFlowCategory(), claimMainStatusEntity.getStatus()));

        return output;
    }


    /**
     * 取得 主流程 目前案件資訊
     * @param clientId 申請人ID
     * @param claimSeq 建檔序號
     * @return ClaimStatusVo 目前案件資訊
     */
    public ClaimStatusVO getClaimStatus(String clientId, Integer claimSeq) {
        if (StringUtils.isEmpty(clientId)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：clientId 空白");
        }
        if (StringUtils.isEmpty(claimSeq)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：claimSeq 空白");
        }

        // 取得 目前案件資訊
        List<ClaimMainStatusEntity> claimMainStatusEntityList =  claimStatusRepository.findByClientIdAndClaimSeq(clientId, claimSeq);
        if (CollectionUtils.isEmpty(claimMainStatusEntityList)) {
            return null;
        } else {
            // 設定回傳
            ClaimStatusVO claimStatusVo = new ClaimStatusVO();
            BeanUtils.copyProperties(claimMainStatusEntityList.get(0), claimStatusVo);
            claimStatusVo.setStatusDesc(ClaimStatusEnum.getDescByStatusCode(claimStatusVo.getStatus()));

            return claimStatusVo;
        }
    }

    /**
     * 取得 案件歷史資訊
     * @param clientId 申請人ID
     * @param claimSeq 建檔序號
     * @return List<ClaimHistoryVo> 案件歷史資訊
     */
    public List<ClaimHistoryVO> getClaimHistory(String clientId, Integer claimSeq) {
        if (StringUtils.isEmpty(clientId)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：clientId 空白");
        }
        if (StringUtils.isEmpty(claimSeq)) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "輸入參數錯誤：claimSeq 空白");
        }

        // 取得 案件歷史資訊
        List<ClaimHistoryEntity> claimHistoryEntityList =  claimHistoryRepository.findByClientIdAndClaimSeq(clientId, claimSeq);
        // 排序
        Comparator<ClaimHistoryEntity> comparator1 = Comparator.comparing(ClaimHistoryEntity::getProcessDate);
        Comparator<ClaimHistoryEntity> comparator2 = Comparator.comparing(ClaimHistoryEntity::getProcessTime);
        claimHistoryEntityList.sort(comparator1.thenComparing(comparator2));
        // 設定回傳
        List<ClaimHistoryVO> claimHistoryVOList = new ArrayList<>();
        for (ClaimHistoryEntity claimHistoryEntity : claimHistoryEntityList) {
            String mainStatusDesc = flowDefinitionService.getStatusDesc(SYSTEM_TYPE, "M", claimHistoryEntity.getMainFlowCategory(), claimHistoryEntity.getMainStatus());
            String subStatusDesc = flowDefinitionService.getStatusDesc(SYSTEM_TYPE, "S", claimHistoryEntity.getSubFlowCategory(), claimHistoryEntity.getSubStatus());
            String flowTypeDesc = claimHistoryEntity.getFlowType().equals("M") ? "主流程" : "子流程";

            ClaimHistoryVO claimHistoryVo = new ClaimHistoryVO();
            BeanUtils.copyProperties(claimHistoryEntity, claimHistoryVo);
            claimHistoryVo.setMainStatus(claimHistoryEntity.getMainStatus() + " " + mainStatusDesc);
            claimHistoryVo.setSubStatus(claimHistoryEntity.getSubStatus() + " " + subStatusDesc);
            claimHistoryVo.setFlowType(claimHistoryEntity.getFlowType() + " " + flowTypeDesc);

            claimHistoryVOList.add(claimHistoryVo);
        }

        return claimHistoryVOList;
    }
}
