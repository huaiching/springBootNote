package com.mli.flow.controller;

import com.mli.flow.dto.ClaimMainStatusDTO;
import com.mli.flow.dto.ClientIdAndClaimSeqDTO;
import com.mli.flow.service.ClaimFlowMainService;
import com.mli.flow.vo.ClaimStatusVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/claimFlowMain")
@Tag(name = "Claim Flow Main Controller", description = "理賠流程引擎 主流程 API")
public class ClaimFlowMainController {
    @Autowired
    private ClaimFlowMainService claimFlowMainService;

    @PostMapping("/createClaimMainStatus/v1")
    @Operation(summary = "主流程 新增案件", description = "主流程 新增案件")
    public ResponseEntity<ClaimStatusVO> createClaimMainStatus(@RequestBody ClaimMainStatusDTO claimMainStatusDTO) {
        return ResponseEntity.ok(claimFlowMainService.createClaimMainStatus(claimMainStatusDTO));
    }

    @PostMapping("/nextClaimMainStatus/v1")
    @Operation(summary = "主流程 前往下一關", description = "主流程 前往下一關")
    public ResponseEntity<ClaimStatusVO> nextClaimMainStatus(@RequestBody ClaimMainStatusDTO claimMainStatusDTO) {
        return ResponseEntity.ok(claimFlowMainService.nextClaimMainStatus(claimMainStatusDTO));
    }

    @PostMapping("/prewClaimMainStatus/v1")
    @Operation(summary = "主流程 返回上一關", description = "主流程 返回上一關")
    public ResponseEntity<ClaimStatusVO> prewClaimMainStatus(@RequestBody ClaimMainStatusDTO claimMainStatusDTO) {
        return ResponseEntity.ok(claimFlowMainService.prewClaimMainStatus(claimMainStatusDTO));
    }

    @PostMapping("/getClaimStatus/v1")
    @Operation(summary = "取得 主流程 目前案件資訊", description = "取得 主流程 目前案件資訊")
    public ResponseEntity<ClaimStatusVO> getClaimStatus(@RequestBody ClientIdAndClaimSeqDTO clientIdAndClaimSeqDto) {
        return ResponseEntity.ok(claimFlowMainService.getClaimStatus(clientIdAndClaimSeqDto.getClientId(), clientIdAndClaimSeqDto.getClaimSeq()));
    }
}
