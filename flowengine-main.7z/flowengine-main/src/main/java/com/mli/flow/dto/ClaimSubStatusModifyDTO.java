package com.mli.flow.dto;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "理賠 子流程變更 輸入資料 (案件修改)")
public class ClaimSubStatusModifyDTO {
    @Schema(description = "子流程 UUID")
    private String subUuid;
    @Schema(description = "負責人")
    private String omnerUser;
    @Schema(description = "處理者")
    private String processUser;
    @Schema(description = "意見")
    private String note;

    public String getSubUuid() {
        return subUuid;
    }

    public void setSubUuid(String subUuid) {
        this.subUuid = subUuid;
    }

    public String getOmnerUser() {
        return omnerUser;
    }

    public void setOmnerUser(String omnerUser) {
        this.omnerUser = omnerUser;
    }

    public String getProcessUser() {
        return processUser;
    }

    public void setProcessUser(String processUser) {
        this.processUser = processUser;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
