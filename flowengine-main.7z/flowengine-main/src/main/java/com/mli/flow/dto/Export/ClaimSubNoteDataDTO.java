package com.mli.flow.dto.Export;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "案件子流程 簽核意見表 - 子流程資料")
public class ClaimSubNoteDataDTO {
    @Schema(description = "子流程節點")
    private String subStatus;
    @Schema(description = "負責人")
    private String ownerUser;
    @Schema(description = "處理日期")
    private String processDate;
    @Schema(description = "處理時間")
    private String processTime;
    @Schema(description = "簽核意見")
    private String note;

    public String getSubStatus() {
        return subStatus;
    }

    public void setSubStatus(String subStatus) {
        this.subStatus = subStatus;
    }

    public String getOwnerUser() {
        return ownerUser;
    }

    public void setOwnerUser(String ownerUser) {
        this.ownerUser = ownerUser;
    }

    public String getProcessDate() {
        return processDate;
    }

    public void setProcessDate(String processDate) {
        this.processDate = processDate;
    }

    public String getProcessTime() {
        return processTime;
    }

    public void setProcessTime(String processTime) {
        this.processTime = processTime;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
